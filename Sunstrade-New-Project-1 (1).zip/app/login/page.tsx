'use client';
import { FormEvent, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { createClient } from '../../utils/supabase/client';

export default function Login() {
  const supabase=createClient(); const router=useRouter(); const [email,setEmail]=useState(''); const [password,setPassword]=useState(''); const [error,setError]=useState('');
  async function submit(e:FormEvent){e.preventDefault();setError('');const {error}=await supabase.auth.signInWithPassword({email,password});if(error){setError(error.message);return;}router.push('/dashboard');router.refresh();}
  return <div className="card"><h1>Login</h1><form onSubmit={submit}><label>Email</label><input className="input" type="email" value={email} onChange={e=>setEmail(e.target.value)} required /><label>Password</label><input className="input" type="password" value={password} onChange={e=>setPassword(e.target.value)} required />{error&&<p className="error">{error}</p>}<button className="btn" type="submit">Login</button></form><p className="muted">No account? <Link href="/signup">Create one</Link></p></div>;
}
