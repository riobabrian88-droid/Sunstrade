'use client';
import { FormEvent, useState } from 'react';
import Link from 'next/link';
import { createClient } from '../../utils/supabase/client';

export default function Signup() {
  const supabase = createClient();
  const [name,setName]=useState(''); const [email,setEmail]=useState(''); const [country,setCountry]=useState(''); const [password,setPassword]=useState(''); const [confirm,setConfirm]=useState(''); const [message,setMessage]=useState(''); const [error,setError]=useState('');

  async function submit(e:FormEvent) {
    e.preventDefault(); setError(''); setMessage('');
    if(password!==confirm){setError('Passwords do not match.');return;}
    if(password.length<6){setError('Password must be at least 6 characters.');return;}
    const {error}=await supabase.auth.signUp({email,password,options:{data:{name,country}}});
    if(error){setError(error.message);return;}
    setMessage('Account created. Check your email if email confirmation is enabled.');
  }

  return <div className="card"><h1>Create account</h1><p className="muted">Join Sunstrade.</p>
    <form onSubmit={submit}>
      <label>Name</label><input className="input" value={name} onChange={e=>setName(e.target.value)} required />
      <label>Email</label><input className="input" type="email" value={email} onChange={e=>setEmail(e.target.value)} required />
      <label>Country</label><input className="input" value={country} onChange={e=>setCountry(e.target.value)} required />
      <label>Password</label><input className="input" type="password" value={password} onChange={e=>setPassword(e.target.value)} required />
      <label>Confirm password</label><input className="input" type="password" value={confirm} onChange={e=>setConfirm(e.target.value)} required />
      {error&&<p className="error">{error}</p>}{message&&<p className="success">{message}</p>}
      <button className="btn" type="submit">Create Account</button>
    </form>
    <p className="muted">Already have an account? <Link href="/login">Login</Link></p>
  </div>;
}
